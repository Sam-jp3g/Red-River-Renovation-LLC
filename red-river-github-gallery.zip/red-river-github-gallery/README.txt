RED RIVER GALLERY / GITHUB PAGES
1. Put actual JPEG photos in photos/ as photo1.jpg ... photo6.jpg. Do not just rename PNG/HEIC files to .jpg.
2. Change image titles and categories in the projects list in index.html if needed.
3. Change MAIN_WEBSITE_URL = '#' to the actual published Canva website URL to enable BACK TO MAIN WEBSITE.
4. Upload index.html, README.txt and photos/ folder to the repository root. Do NOT upload the ZIP itself to GitHub Pages.
5. Repository > Settings > Pages > Deploy from a branch > main > /(root) > Save.
6. Publishable files are public. Obtain client approval before putting photographs online.
